package com.atik.engine

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

// ══════════════════════════════════════════════════════════════════════════════
// LAYER C — MainActivity.kt
// Atik Engine Pro · com.atik.engine
// ══════════════════════════════════════════════════════════════════════════════

class MainActivity : AppCompatActivity() {

    // ── WebView instance (created programmatically — no XML layout) ──────────
    private lateinit var webView: WebView

    // ── Status polling runnable ──────────────────────────────────────────────
    private val statusPoller = object : Runnable {
        override fun run() {
            refreshEngineStatus()
            webView.postDelayed(this, STATUS_POLL_INTERVAL_MS)
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onCreate — LAUNCH-TIME GATEKEEPER
    // ════════════════════════════════════════════════════════════════════════
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ── Immersive full-screen flags ──────────────────────────────────────
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        window.statusBarColor = Color.parseColor("#090d16")

        // ── GATEKEEPER: Redirect immediately if service is not enabled ───────
        if (!isAccessibilityServiceEnabled()) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
            return
        }

        // ── Build WebView programmatically (no XML dependency) ───────────────
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#090d16"))
        }

        configureWebView()

        // ── Root container ───────────────────────────────────────────────────
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#090d16"))
            addView(webView)
        }
        setContentView(root)

        // ── Expose this activity instance to the Accessibility Service ───────
        AutoAcceptService.mainActivity = this

        // ── Load the embedded dashboard ──────────────────────────────────────
        webView.loadUrl("file:///android_asset/index.html")
    }

    // ════════════════════════════════════════════════════════════════════════
    //  WebView Configuration
    // ════════════════════════════════════════════════════════════════════════
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        // ── JavaScript Bridge — exposes "Android" object to HTML/JS ──────────
        webView.addJavascriptInterface(AndroidBridge(), "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Push current engine state once page has loaded
                refreshEngineStatus()
            }
        }
        webView.webChromeClient = WebChromeClient()
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onResume — Start continuous status polling
    // ════════════════════════════════════════════════════════════════════════
    override fun onResume() {
        super.onResume()
        // ── Re-gate: if service was disabled while app was in background ─────
        if (!isAccessibilityServiceEnabled()) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            return
        }
        webView.post { webView.postDelayed(statusPoller, STATUS_POLL_INTERVAL_MS) }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onPause — Stop polling to conserve resources
    // ════════════════════════════════════════════════════════════════════════
    override fun onPause() {
        super.onPause()
        webView.removeCallbacks(statusPoller)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onDestroy — Clean up bridge reference
    // ════════════════════════════════════════════════════════════════════════
    override fun onDestroy() {
        super.onDestroy()
        AutoAcceptService.mainActivity = null
        webView.removeCallbacks(statusPoller)
        webView.destroy()
    }

    // ════════════════════════════════════════════════════════════════════════
    //  pushStatusToWebView — Thread-safe UI update from any thread
    //  REQUIREMENT: All calls into WebView must be dispatched via webView.post{}
    // ════════════════════════════════════════════════════════════════════════
    fun pushStatusToWebView(isActive: Boolean) {
        val js = "window.updateEngineStatus(${if (isActive) "true" else "false"});"
        webView.post {
            webView.evaluateJavascript(js, null)
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  refreshEngineStatus — Query service state and push to dashboard
    // ════════════════════════════════════════════════════════════════════════
    private fun refreshEngineStatus() {
        val isRunning = AutoAcceptService.isRunning && isAccessibilityServiceEnabled()
        pushStatusToWebView(isRunning)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  isAccessibilityServiceEnabled — System-level service detection
    // ════════════════════════════════════════════════════════════════════════
    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName = ComponentName(this, AutoAcceptService::class.java)
        val enabledServicesSetting = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServicesSetting)
        while (colonSplitter.hasNext()) {
            val componentNameString = colonSplitter.next()
            val enabledService = ComponentName.unflattenFromString(componentNameString)
            if (enabledService != null && enabledService == expectedComponentName) {
                return true
            }
        }
        return false
    }

    // ════════════════════════════════════════════════════════════════════════
    //  AndroidBridge — @JavascriptInterface methods exposed to HTML/JS
    // ════════════════════════════════════════════════════════════════════════
    inner class AndroidBridge {

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        }

        @JavascriptInterface
        fun isServiceEnabled(): Boolean {
            return isAccessibilityServiceEnabled() && AutoAcceptService.isRunning
        }

        @JavascriptInterface
        fun getClickCount(): Long {
            return AutoAcceptService.totalClickCount
        }

        @JavascriptInterface
        fun getAppVersion(): String {
            return try {
                packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
            } catch (e: Exception) {
                "1.0.0"
            }
        }

        @JavascriptInterface
        fun getPackageName(): String = packageName

        @JavascriptInterface
        fun minimizeApp() {
            runOnUiThread {
                moveTaskToBack(true)
            }
        }
    }

    companion object {
        private const val STATUS_POLL_INTERVAL_MS = 1500L
    }
}
