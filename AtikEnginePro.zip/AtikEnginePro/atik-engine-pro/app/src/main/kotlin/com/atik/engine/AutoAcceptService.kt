package com.atik.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

// ══════════════════════════════════════════════════════════════════════════════
// LAYER D — AutoAcceptService.kt
// Atik Engine Pro · com.atik.engine
// ══════════════════════════════════════════════════════════════════════════════

class AutoAcceptService : AccessibilityService() {

    // ── Background thread worker (single-thread executor for serial processing) ──
    private val workerExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "AtikEngine-Worker").also { it.isDaemon = true }
    }

    // ── Cooldown gate: prevents multi-fire on the same node ─────────────────
    private val isBusy = AtomicBoolean(false)

    // ── Timestamp formatter for logcat output ────────────────────────────────
    private val timestampFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    // ════════════════════════════════════════════════════════════════════════
    //  onServiceConnected — Service initialisation
    // ════════════════════════════════════════════════════════════════════════
    override fun onServiceConnected() {
        super.onServiceConnected()

        val info = AccessibilityServiceInfo().apply {
            eventTypes = (
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                    or AccessibilityEvent.TYPE_WINDOWS_CHANGED
                    or AccessibilityEvent.TYPE_VIEW_CLICKED
                )
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 10L
            flags = (
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                )
        }
        serviceInfo = info

        isRunning = true
        Log.i(TAG, "[$TAG] Service connected — Atik Engine Pro is ONLINE")

        // Notify the dashboard if the activity is alive
        mainActivity?.pushStatusToWebView(true)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onAccessibilityEvent — Entry point for all captured UI events
    // ════════════════════════════════════════════════════════════════════════
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        // Skip irrelevant event types fast
        val type = event.eventType
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOWS_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_CLICKED
        ) return

        // Offload heavy node traversal to the background worker thread
        workerExecutor.execute { scanAndClick() }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  scanAndClick — Core processing pipeline
    //  ► Runs on background worker thread (never on the UI / Main thread)
    // ════════════════════════════════════════════════════════════════════════
    private fun scanAndClick() {
        // ── REQUIREMENT: Memory-leak mitigation via null-safety guard ────────
        val root = rootInActiveWindow ?: return

        // ── Cooldown: if already handling a click, skip duplicate events ─────
        if (!isBusy.compareAndSet(false, true)) {
            root.recycle()
            return
        }

        try {
            findAndClickAcceptNode(root)
        } finally {
            isBusy.set(false)
            root.recycle()
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  findAndClickAcceptNode — Recursive DFS node searcher
    //  Searches the full accessibility tree for any node whose text or
    //  contentDescription contains "accept" (case-insensitive).
    // ════════════════════════════════════════════════════════════════════════
    private fun findAndClickAcceptNode(node: AccessibilityNodeInfo?) {
        node ?: return

        val childCount = node.childCount
        for (i in 0 until childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (isAcceptNode(child)) {
                    // ── REQUIREMENT: Recursive bubble-up to clickable parent ─
                    val clickableTarget = resolveClickableAncestor(child)
                    if (clickableTarget != null) {
                        performClickAndLog(clickableTarget)
                        // Recycle non-clicked child reference
                        if (clickableTarget !== child) child.recycle()
                        return
                    }
                }
                // Recurse deeper into the tree
                findAndClickAcceptNode(child)
            } finally {
                // Only recycle if we haven't already handed it to clickableTarget
            }
            child.recycle()
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  isAcceptNode — Keyword matcher (text + contentDescription)
    // ════════════════════════════════════════════════════════════════════════
    private fun isAcceptNode(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""
        return text.contains(TARGET_KEYWORD, ignoreCase = true) ||
            desc.contains(TARGET_KEYWORD, ignoreCase = true)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  resolveClickableAncestor — REQUIREMENT: Recursive bubble-up
    //  If the discovered node itself is not clickable, walk up through .parent
    //  until we find the first ancestor that IS clickable.
    // ════════════════════════════════════════════════════════════════════════
    private fun resolveClickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isClickable && node.isEnabled) return node

        var current: AccessibilityNodeInfo? = node.parent
        var depth = 0

        while (current != null && depth < MAX_BUBBLE_DEPTH) {
            if (current.isClickable && current.isEnabled) {
                return current
            }
            val parent = current.parent
            current.recycle()
            current = parent
            depth++
        }

        // No clickable ancestor found within depth limit
        current?.recycle()
        return null
    }

    // ════════════════════════════════════════════════════════════════════════
    //  performClickAndLog — Execute the tap and emit a timestamped log entry
    // ════════════════════════════════════════════════════════════════════════
    private fun performClickAndLog(node: AccessibilityNodeInfo) {
        val success = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (success) {
            val count = totalClickCount.incrementAndGet()
            val timestamp = timestampFmt.format(Date())
            Log.i(
                TAG,
                "[$TAG] ✓ CLICK #$count | Time: $timestamp | Node: \"${node.text ?: node.contentDescription}\" | Class: ${node.className}"
            )
            // Push updated click count to dashboard (thread-safe via webView.post)
            mainActivity?.pushStatusToWebView(true)
        } else {
            Log.w(TAG, "[$TAG] ✗ Click ACTION failed on node: \"${node.text ?: node.contentDescription}\"")
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onInterrupt — Service was interrupted by system
    // ════════════════════════════════════════════════════════════════════════
    override fun onInterrupt() {
        Log.w(TAG, "[$TAG] Service interrupted by system")
    }

    // ════════════════════════════════════════════════════════════════════════
    //  onUnbind — Service is being shut down
    // ════════════════════════════════════════════════════════════════════════
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        isRunning = false
        totalClickCount.set(0L)
        workerExecutor.shutdownNow()
        Log.i(TAG, "[$TAG] Service unbound — Atik Engine Pro is OFFLINE")
        mainActivity?.pushStatusToWebView(false)
        return super.onUnbind(intent)
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Companion — Shared state accessible from MainActivity
    // ════════════════════════════════════════════════════════════════════════
    companion object {
        private const val TAG = "AtikEngine"
        private const val TARGET_KEYWORD = "Accept"
        private const val MAX_BUBBLE_DEPTH = 8

        // Volatile flags — safe for cross-thread reads from MainActivity
        @Volatile var isRunning: Boolean = false

        // AtomicLong for thread-safe click counting
        val totalClickCount = AtomicLong(0L)

        // Weak reference pattern to prevent Activity memory leak
        private var _mainActivity: WeakReference<MainActivity>? = null
        var mainActivity: MainActivity?
            get() = _mainActivity?.get()
            set(value) {
                _mainActivity = if (value != null) WeakReference(value) else null
            }
    }
}
