# ══════════════════════════════════════════════════════════════
# ProGuard Rules — Atik Engine Pro
# ══════════════════════════════════════════════════════════════

# Keep all JavaScript interface methods (called by WebView via reflection)
-keepclassmembers class com.atik.engine.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep the AccessibilityService (system binds it by reflection)
-keep class com.atik.engine.AutoAcceptService { *; }

# Keep MainActivity
-keep class com.atik.engine.MainActivity { *; }

# Standard Android rules
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception

# Kotlin intrinsics
-dontwarn kotlin.**
-keep class kotlin.** { *; }
